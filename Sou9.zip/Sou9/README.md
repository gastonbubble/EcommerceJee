# Online Shopping platform(E-commerce website)
## About:
Welcome to the E-Commerce Website project! This web application is designed to provide a seamless online shopping called Sou9 to users while empowering administrators with efficient management tools.
  

### Technologies used:-
1. Front-End Development:
- HTML
- CSS
- Javascript/jQuery
- BootStrap

2. Back-End Development:
- Java 
-	JDBC (Java Database Connectivity)
-	Servlet
-	JSP (JavaServer Pages)

3. Database:
- MySql

4. Software and Tools
- Eclipse EE
- Tomcat
- MySQL workbench

###  Jar files used :
- mysql-connector-j-8.0.31
- angus-activation-2.0.1
- jakarta.activation-api-2.1.2
- jakarta.mail-2.0.1